main trigger:
0011001001100
