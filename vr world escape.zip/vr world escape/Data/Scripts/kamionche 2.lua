main duration:
011001101001001101101101001
stop:
control shift tab